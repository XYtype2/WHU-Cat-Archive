// index.js - deleteImage 云函数
const COS = require('cos-nodejs-sdk-v5');

const BUCKET = 'whutnr-1311545081';
const REGION = 'ap-guangzhou';

const cos = new COS({
  SecretId: 'AKIDJVXN0TlwvhGeqrkSyHSUL1Zx980hXHwX',
  SecretKey: 'a2LSSK1Y1Pgs15wb3MekeMrBE6m9RYgj'
});

function isSafeFileName(fileName) {
  if (typeof fileName !== 'string' || !fileName) return false;
  if (fileName.length > 120) return false;
  if (fileName.includes('/') || fileName.includes('\\') || fileName.includes('..')) return false;
  return /\.(jpg|jpeg|png)$/i.test(fileName);
}

function isSafeCatName(catName) {
  if (typeof catName !== 'string' || !catName.trim()) return false;
  if (catName.length > 100) return false;
  if (catName.includes('/') || catName.includes('\\') || catName.includes('..')) return false;
  return true;
}

function deleteObject(Key) {
  return new Promise((resolve, reject) => {
    cos.deleteObject({ Bucket: BUCKET, Region: REGION, Key }, (err, data) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(data);
    });
  });
}

function copyObject({ sourceKey, targetKey }) {
  const copySource = `${BUCKET}.cos.${REGION}.myqcloud.com/${encodeURI(sourceKey)}`;
  return new Promise((resolve, reject) => {
    cos.putObjectCopy({
      Bucket: BUCKET,
      Region: REGION,
      Key: targetKey,
      CopySource: copySource
    }, (err, data) => {
      if (err) {
        reject(err);
        return;
      }
      resolve(data);
    });
  });
}

module.exports = async (ctx) => {
  try {
    console.log('【deleteImage 开始执行】收到参数:', !!ctx.args);
    const { fileName, catName, indexToDelete, currentCount } = ctx.args || {};

    // 1) 兼容旧调用：直接按 fileName 删除
    if (fileName) {
      if (!isSafeFileName(fileName)) {
        console.log('【错误】非法文件名:', fileName);
        return { success: false, error: 'Invalid file name' };
      }

      const key = `picture/${fileName}`;
      console.log('【准备删除】Key:', key);
      await deleteObject(key);
      console.log('【删除成功】', key);
      return { success: true };
    }

    // 2) 新调用：删除附加图并自动重排，如 name2.jpg 删除后，name3.jpg -> name2.jpg
    if (!isSafeCatName(catName)) {
      console.log('【错误】非法 catName:', catName);
      return { success: false, error: 'Invalid catName' };
    }

    const deleteIndex = Number(indexToDelete);
    const totalCount = Number(currentCount);

    if (
      !Number.isInteger(deleteIndex) ||
      !Number.isInteger(totalCount) ||
      deleteIndex < 1 ||
      totalCount < 1 ||
      deleteIndex > totalCount
    ) {
      return { success: false, error: 'Invalid indexToDelete/currentCount' };
    }

    // 从被删位后面的图片开始前移覆盖，最后删除尾图
    for (let i = deleteIndex + 1; i <= totalCount; i++) {
      const sourceKey = `picture/${catName}${i}.jpg`;
      const targetKey = `picture/${catName}${i - 1}.jpg`;
      console.log(`【重排复制】${sourceKey} -> ${targetKey}`);
      await copyObject({ sourceKey, targetKey });
    }

    const tailKey = `picture/${catName}${totalCount}.jpg`;
    console.log('【删除尾图】', tailKey);
    await deleteObject(tailKey);

    return {
      success: true,
      newCount: totalCount - 1
    };

  } catch (err) {
    console.error('【deleteImage 异常】', err.message, err.stack);
    return { 
      success: false,
      error: 'Delete failed',
      message: err.message 
    };
  }
};
